#include "vex.h"
#include <iostream>
vex::brain Brain;

vex::motor leftF1 = vex::motor(vex::PORT11,false);
vex::motor leftF2 = vex::motor(vex::PORT18,false);
vex::motor leftB = vex::motor(vex::PORT2,true);
vex::motor rightF1 = vex::motor(vex::PORT12,vex::gearSetting::ratio18_1,true);
vex::motor rightF2 = vex::motor(vex::PORT16,vex::gearSetting::ratio18_1,true);
vex::motor rightB = vex::motor(vex::PORT3,vex::gearSetting::ratio18_1,false);
vex::motor catapult = vex::motor(vex::PORT13,vex::gearSetting::ratio36_1, true);
vex::motor catapult2 = vex::motor(vex::PORT14,vex::gearSetting::ratio36_1,false);
vex::motor roller = vex::motor(vex::PORT1,vex::gearSetting::ratio6_1,false);
vex::motor uptake = vex::motor(vex::PORT10,vex::gearSetting::ratio6_1,true);
vex::motor flipper = vex::motor(vex::PORT17,vex::gearSetting::ratio18_1,false);
vex::motor descorer = vex::motor(vex::PORT15,vex::gearSetting::ratio18_1,false);


vex::controller Grant = vex::controller();

vex::bumper Cbutton = vex::bumper(Brain.ThreeWirePort.F);
vex::digital_out Intake = vex::digital_out(Brain.ThreeWirePort.E);
vex::gyro gyro = vex::gyro(Brain.ThreeWirePort.A);
vex::line backBall = vex::line(Brain.ThreeWirePort.C);
vex::line frontBall = vex::line(Brain.ThreeWirePort.B);
vex::digital_out blocker = vex::digital_out(Brain.ThreeWirePort.D);
vex::vision VisionLion = vex::vision(vex::PORT19);


Robot::Robot(bool autonomous){
  auton = autonomous;
  if(auton){
    autoInit();
  }else{
    start();
  }
}

void driver(void* param){
  double power, turn;
  std::string errorCheck;
  while(true){
    power = 200*(Grant.Axis3.value()/127.0);
    turn = 200*((Grant.Axis1.value()/127.0));
    if(fabs(power) < 8){
      power = 0;
    }
    if(fabs(turn) < 7 ){
      turn = 0;
    }
    rightF1.setVelocity(power-turn, vex::rpm);
    rightF2.setVelocity(power-turn, vex::rpm);
    rightB.setVelocity(power-turn, vex::rpm);
    leftB.setVelocity(power+turn, vex::rpm);
    leftF1.setVelocity(power+turn, vex::rpm);
    leftF2.setVelocity(power+turn, vex::rpm);

    vex::task::sleep(10);
  }
}
void Robot::start(){
  state = true;
  Intake.set(state);
  roller.setVelocity(100, vex::pct);
  uptake.setVelocity(100, vex::pct);
  descorer.setBrake(vex::coast);
  flipper.setBrake(vex::hold);
  catapult.setBrake(vex::hold);
  catapult2.setBrake(vex::hold);
  rightF1.setBrake(vex::coast);
  rightF2.setBrake(vex::coast);
  rightB.setBrake(vex::coast);
  leftF1.setBrake(vex::coast);
  leftF2.setBrake(vex::coast);
  leftB.setBrake(vex::coast);

}
void Robot::clearAll(){
  flipper.setVelocity(50, vex::rpm);
  descorer.setVelocity(50, vex::rpm);
  Intake.set(state);
  bool go = true;
  vex::task::sleep(75);
  while(go){
    go = false;
    if(flipper.velocity(vex::rpm) > 5){
      go = true;
    }else{
      flipper.setVelocity(0, vex::rpm);
    }
    if(descorer.velocity(vex::rpm) > 5){
      go = true;
    }else{
      descorer.setVelocity(0, vex::rpm);
    }
  }
  descorer.resetRotation();
  flipper.resetRotation();
}

void Robot::OPclear(){
  if(Grant.ButtonA.pressing()){
    clearAll();
  }
}

void Robot::toggleFlipper(){
  if(auton){
    if(flipper.rotation(vex::deg) < -50){
      flipper.rotateTo(-125, vex::deg, 200, vex::rpm);
    }else{
      flipper.rotateTo(-10, vex::deg, 100, vex::rpm);
    }
  }else{
    if(Grant.ButtonR2.pressing() && !lastR2){
      lastR2 = true;
      if(flipper.rotation(vex::deg) < -50){
        flipper.rotateTo(-10, vex::deg, 200, vex::rpm);
      }else{
        flipper.rotateTo(-125, vex::deg, 100, vex::rpm);
      }
    }
    if(Grant.ButtonR2.pressing()){
      lastR2 = false;
    }
  }
}

void Robot::toggleDescorer(){
  if(auton){
    if(descorer.rotation(vex::deg) < -50){
      descorer.rotateTo(-10, vex::deg, 100, vex::rpm);
      descorer.setBrake(vex::coast);
    }else{
      descorer.rotateTo(-220, vex::deg, 100, vex::rpm);
      descorer.setBrake(vex::hold);
    }
  }else{
    if(Grant.ButtonR1.pressing() && lastR1){
      lastR1 = true;
      if(descorer.rotation(vex::deg) < -100){
        descorer.setVelocity(100, vex::rpm);
        descorerOut = false;
      }else{
        descorer.rotateTo(-325, vex::deg, 100, vex::rpm);
        descorerOut = true;
      }
    }else if(!descorerOut){
      if(descorer.rotation(vex::deg) > -30){
        descorer.setVelocity(0, vex::rpm);
        descorer.setBrake(vex::coast);
      }
    }
      if(!Grant.ButtonR1.pressing()){
        lastR1 = false;
      }
  }
}



void Robot::toggleIntake(double direction = 0){
  if(auton){
    if(direction == 0){
      state = false;
      Intake.set(state);
      roller.setVelocity(0, vex::rpm);
      uptake.setVelocity(0, vex::rpm);
    }else if(direction > 0){
      state = true;
      Intake.set(state);
      vex::task::sleep(200);
      roller.setVelocity(600, vex::rpm);
      uptake.setVelocity(600, vex::rpm);
    }else{
      state = true;
      Intake.set(state);
      vex::task::sleep(200);
      roller.setVelocity(-600, vex::rpm);
      uptake.setVelocity(-600, vex::rpm);
    }
  }else{
    if(Grant.ButtonX.pressing() && !lastX){
      lastX = true;     //new press
      state = !state;
      Intake.set(state);
      roller.setVelocity((int)state * 600, vex::rpm);
      uptake.setVelocity((int)state * 600, vex::rpm);
    }
     if(!Grant.ButtonX.pressing()){
       lastX = false;
     }
    if(state){
      if(Grant.ButtonRight.pressing()){
        roller.setVelocity(-600, vex::rpm);
        uptake.setVelocity(-600, vex::rpm);
      }else if(Grant.ButtonL2.pressing()){
        roller.setVelocity(-250, vex::rpm);
        uptake.setVelocity(-600, vex::rpm);
      }else{
        
        roller.setVelocity(600, vex::rpm);
        uptake.setVelocity(600, vex::rpm);
      }
    }
  }
}

void Robot::fire(){
  if(auton){
    while(!Cbutton.pressing()){
      catapult.setVelocity(200, vex::rpm);
      catapult2.setVelocity(200, vex::rpm);
      vex::task::sleep(20);
    }
    while(Cbutton.pressing()){
      catapult.setVelocity(200, vex::rpm);
      catapult2.setVelocity(200, vex::rpm);
      vex::task::sleep(20);
    }
    vex::task::sleep(300);
    while(!Cbutton.pressing()){
      catapult.setVelocity(200, vex::rpm);
      catapult2.setVelocity(200, vex::rpm);
      vex::task::sleep(20);
    }
    catapult.setVelocity(0, vex::rpm);
    catapult2.setVelocity(0, vex::rpm);
  }else{
    if(catapultOn){
      if(!Cbutton.pressing()){
        catapult.setVelocity(200, vex::rpm);
        catapult2.setVelocity(200, vex::rpm);
      }else if(Grant.ButtonL1.pressing()){
        catapult.setVelocity(200, vex::rpm);
        catapult2.setVelocity(200, vex::rpm);
      }else{
        catapult.setVelocity(0, vex::rpm);
        catapult2.setVelocity(0, vex::rpm);
      }
    }
    if(Grant.ButtonY.pressing() && !lastY){
      lastY = true;
      catapultOn = !catapultOn;
      if(catapultOn){
        catapult.setBrake(vex::hold);
        catapult2.setBrake(vex::hold);
        catapult.setVelocity(200, vex::rpm);
        catapult2.setVelocity(200, vex::rpm);
      }else{
        catapult.setBrake(vex::coast);
        catapult2.setBrake(vex::coast);
        catapult.setVelocity(0, vex::rpm);
        catapult2.setVelocity(0, vex::rpm);
      }
    }
    if(!Grant.ButtonY.pressing()){
      lastY = false;
    }
  }
}

void Robot::visionYeet(){
  if(auton){

  }else{
    if(Grant.ButtonB.pressing()){

    }
  }
}

/*
pros::Motor rightF1(LeftF,pros::E_MOTOR_GEARSET_18,true,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor rightF2(LeftM,pros::E_MOTOR_GEARSET_18,false,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor rightB(LeftB,pros::E_MOTOR_GEARSET_18,false,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor leftF1(RightF,pros::E_MOTOR_GEARSET_18,false,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor leftF2(RightM,pros::E_MOTOR_GEARSET_18,false,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor leftB(RightB,pros::E_MOTOR_GEARSET_18,true,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor catapult(Cata,pros::E_MOTOR_GEARSET_36,true,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor catapult2(Cata2,pros::E_MOTOR_GEARSET_36,false,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor flipper(Flipper,pros::E_MOTOR_GEARSET_18,false,pros::E_MOTOR_ENCODER_DEGREES);
pros::Controller Grant (CONTROLLER_MASTER);
pros::Motor roller(Roller,pros::E_MOTOR_GEARSET_06,false,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor uptake(Uptake,pros::E_MOTOR_GEARSET_06,true,pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor descorer(PokeBar,pros::E_MOTOR_GEARSET_18,false,pros::E_MOTOR_ENCODER_DEGREES);

pros::ADIDigitalIn Cbutton(CatButton);
pros::ADIDigitalOut Intake(InPiston);
*/
//////////AUTONOMOUS FUNCTIONS//////////

void Robot::autoInit(){
  rightF1.resetRotation();
  rightF2.resetRotation();
  rightB.resetRotation();
  leftF1.resetRotation();
  leftF2.resetRotation();
  leftB.resetRotation();

  rightF1.setBrake(vex::hold);
  rightF2.setBrake(vex::hold);
  rightB.setBrake(vex::hold);
  leftF1.setBrake(vex::hold);
  leftF2.setBrake(vex::hold);
  leftB.setBrake(vex::hold);
}

void Robot::cataDown(){
  while(!Cbutton.pressing()){
    catapult.setVelocity(100, vex::rpm);
    catapult2.setVelocity(100, vex::rpm);
    vex::task::sleep(10);
  }
  catapult.setVelocity(0, vex::rpm);
  catapult2.setVelocity(0, vex::rpm);
  catapult.setBrake(vex::hold);
  catapult2.setBrake(vex::hold);

}

void Robot::move(double distance, int speed){
  double leftAvg = (leftF1.rotation(vex::deg) + leftB.rotation(vex::deg)) / 2;
  double rightAvg = (rightF1.rotation(vex::deg) + rightB.rotation(vex::deg)) / 2;
  double targetLeft = distance + leftAvg;
  double targetRight = distance + rightAvg;
  double toTargetLeft = distance;
  double toTargetRight = distance;
  double toTargetAvg = distance;
  double agg = 5;
  double leftSpeed = 0;
  double rightSpeed = 0;
  double adjDistance = fabs(distance / 2);
  int dir = distance / abs(distance);


  while(fabs(toTargetLeft) > 10 && fabs(toTargetRight) > 10){
    leftAvg = (leftF1.rotation(vex::deg) + leftB.rotation(vex::deg)) / 2;
    rightAvg = (rightF1.rotation(vex::deg) + rightB.rotation(vex::deg)) / 2;
    toTargetLeft = targetLeft - leftAvg;
    toTargetRight = targetRight - rightAvg;
    toTargetAvg = (toTargetLeft + toTargetRight) / 2;

    /////////////Do Not Change this////////////
    if(fabs(distance) >= 700){
      agg = 700;
      if(fabs(toTargetAvg) < 400){
        leftSpeed = speed * ((toTargetAvg / 450) + (dir * .06) + ((toTargetLeft - toTargetRight) / agg));
        rightSpeed = speed * ((toTargetAvg / 450) + (dir * .06) - ((toTargetLeft - toTargetRight) / agg));
      }else if(fabs(distance - toTargetAvg) < 300){
        leftSpeed = speed * (((distance - toTargetAvg) / 500) + (dir * .35) + ((toTargetLeft - toTargetRight) / agg));
        rightSpeed = speed * (((distance - toTargetAvg) / 500) + (dir * .35) - ((toTargetLeft - toTargetRight) / agg));
      }else{
        leftSpeed = speed * ((dir * .95) + ((toTargetLeft - toTargetRight) / agg));
        rightSpeed = speed * ((dir * .95) - ((toTargetLeft - toTargetRight) / agg));
      }
    }else{
      agg = 400;
      if(fabs(toTargetAvg) < adjDistance){
        leftSpeed = speed * ((toTargetAvg / 450) + (dir * .25) + ((toTargetLeft - toTargetRight) / agg));
        rightSpeed = speed * ((toTargetAvg / 450) + (dir * .25) - ((toTargetLeft - toTargetRight) / agg));
      }else if(fabs(distance - toTargetAvg) < adjDistance){
        leftSpeed = speed * (((distance - toTargetAvg) / 500) + (dir * .35) + ((toTargetLeft - toTargetRight) / agg));
        rightSpeed = speed * (((distance - toTargetAvg) / 500) + (dir * .35) - ((toTargetLeft - toTargetRight) / agg));
      }else{
        leftSpeed = speed * ((dir * .95) + ((toTargetLeft - toTargetRight) / agg));
        rightSpeed = speed * ((dir * .95) - ((toTargetLeft - toTargetRight) / agg));
      }
    }
    leftF1.setVelocity(leftSpeed, vex::rpm);
    leftF2.setVelocity(leftSpeed, vex::rpm);
    leftB.setVelocity(leftSpeed, vex::rpm);
    rightF1.setVelocity(rightSpeed, vex::rpm);
    rightF2.setVelocity(rightSpeed, vex::rpm);
    rightB.setVelocity(rightSpeed, vex::rpm);
    vex::task::sleep(2);
  }
  leftF1.setVelocity(0, vex::rpm);
  leftF2.setVelocity(0, vex::rpm);
  leftB.setVelocity(0, vex::rpm);
  rightF1.setVelocity(0, vex::rpm);
  rightF2.setVelocity(0, vex::rpm);
  rightB.setVelocity(0, vex::rpm);
  vex::task::sleep(100);
}

void Robot::turn(double angle, int speed){
  //double turn90 = 353 - (29.0 * fabs(angle / 90.0));  //90 = 297
  double turn90 = 305 - (10.0 * fabs(angle/90.0));
  double distance = (angle * turn90) / 90.0;
  double leftAvg = leftF1.rotation(vex::deg);
  double rightAvg = rightF1.rotation(vex::deg);
  double targetLeft = -distance + leftAvg;
  double targetRight = distance + rightAvg;
  double toTargetLeft = -distance;
  double toTargetRight = distance;
  double leftSpeed = 0;
  double rightSpeed = 0;
  int dir = angle / abs(angle);


  while(fabs(toTargetLeft) > 10 && fabs(toTargetRight) > 10){
    leftAvg = leftF1.rotation(vex::deg);
    rightAvg = rightF1.rotation(vex::deg);
    toTargetLeft = targetLeft - leftAvg;
    toTargetRight = targetRight - rightAvg;

    if(fabs(toTargetLeft) < 50){
      leftSpeed = (fabs(toTargetLeft / 125) + .6) * -speed * dir;
    }else if(fabs(distance - toTargetLeft) < 50){
      leftSpeed = (.6 + fabs((distance - toTargetLeft)/125)) * -speed * dir;
    }else{
      leftSpeed = -speed * dir;
    }
    if(fabs(toTargetRight) < 50){
      rightSpeed = (fabs(toTargetRight / 125) + .6) * speed * dir;
    }else if(fabs(distance - toTargetRight) < 50){
      rightSpeed = (.6 + fabs((distance - toTargetRight)/125)) * speed * dir;
    }else{
      rightSpeed = speed * dir;
    }
    leftF1.setVelocity(leftSpeed, vex::rpm);
    leftF2.setVelocity(leftSpeed, vex::rpm);
    leftB.setVelocity(leftSpeed, vex::rpm);
    rightF1.setVelocity(rightSpeed, vex::rpm);
    rightF2.setVelocity(rightSpeed, vex::rpm);
    rightB.setVelocity(rightSpeed, vex::rpm);
    vex::task::sleep(2);
  }
  leftF1.setVelocity(0, vex::rpm);
  leftF2.setVelocity(0, vex::rpm);
  leftB.setVelocity(0, vex::rpm);
  rightF1.setVelocity(0, vex::rpm);
  rightF2.setVelocity(0, vex::rpm);
  rightB.setVelocity(0, vex::rpm);
  vex::task::sleep(200);
}

void Robot::endAuto(){
  rightF1.setBrake(vex::coast);
  rightF2.setBrake(vex::coast);
  rightB.setBrake(vex::coast);
  leftF1.setBrake(vex::coast);
  leftF2.setBrake(vex::coast);
  leftB.setBrake(vex::coast);
}
