#include "vex.h"

void Robot::redAuto(){
  Robot lion(true);
  toggleIntake(1);
  vex::task::sleep(200);
  //cataDown();
  move(-1350,200);
  vex::task::sleep(1000);
  move(1100,200);
  vex::task::sleep(500);
  turn(-105,100);
  move(200,200);
  turn(-20,100);
  vex::task::sleep(500);
  fire();
  toggleIntake(0);
  turn(20,100);
  move(1200,200);
  move(-600,200);
  turn(-90,100);
  move(-100,200);
  toggleFlipper();
  move(550,200);
  toggleFlipper();
  vex::task::sleep(200);
  move(-375,200);
  turn(-90,100);              //Red Front
  move(1450,200);
  turn(90,100);
  move(-100,100);
  move(2150,200);
  endAuto();


  endAuto();
}