#include "vex.h"

void Robot::auto1(){
  move(1500,200);
  move(-1500,200);
  move(200,200);
  move(-200,200);

  endAuto();
  /*lion.move(900 ,200);
  lion.endAuto();
  lion.toggleFlipper();
  lion.toggleFlipper();*/

}
