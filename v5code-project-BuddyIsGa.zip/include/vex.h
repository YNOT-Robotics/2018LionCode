/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       vex.h                                                     */
/*    Author:       Vex Robotics                                              */
/*    Created:      1 Feb 2019                                                */
/*    Description:  Default header for V5 projects                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "v5.h"
#include "v5_vcs.h"


void autonomous(void);
void initialize(void);
void disabled(void);
void competition_initialize(void);
void opcontrol(void);
int driver(void);

//defined in lionFunctions.cpp
class Robot{
  public:
    Robot(bool);
    void clearAll();
    void start();
    void toggleFlipper();
    void toggleDescorer();
    void OPclear();
    void toggleIntake(double);
    void fire();
    void visionYeet();
    void toggleBlocker();

      bool lastR2;
      bool lastR1;
      bool lastY;
      bool lastX;

    //auton functions
    void autoInit();
    void cataDown();
    void move(double, int);
    void turn(double, int);
    void endAuto();

    void auto1();
    void redAuto();
  private:

    bool auton;
    bool driveOverride = false;
    bool state = false;
    bool catapultOn = true;
    bool descorerOut = false;
    int xPos = 0;
    int yPos = 0;
    int angle = 0;
};

